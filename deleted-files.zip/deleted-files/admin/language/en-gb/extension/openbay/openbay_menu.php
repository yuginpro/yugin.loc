<?php
// Text
$_['text_openbay_extension']           = 'OpenBay Pro';
$_['text_openbay_dashboard']           = 'Dashboard';
$_['text_openbay_orders']              = 'Bulk order update';
$_['text_openbay_items']               = 'Manage items';
$_['text_openbay_ebay']                = 'eBay';
$_['text_openbay_amazon']              = 'Amazon (EU)';
$_['text_openbay_amazonus']            = 'Amazon (US)';
$_['text_openbay_etsy']            	   = 'Etsy';
$_['text_openbay_settings']            = 'Settings';
$_['text_openbay_links']               = 'Item links';
$_['text_openbay_report_price']        = 'Pricing report';
$_['text_openbay_order_import']        = 'Order import';
$_['text_openbay_fba']                 = 'Fulfillment by Amazon';
$_['text_openbay_fulfillmentlist']     = 'Fulfillments';
$_['text_openbay_orderlist']           = 'Orders';